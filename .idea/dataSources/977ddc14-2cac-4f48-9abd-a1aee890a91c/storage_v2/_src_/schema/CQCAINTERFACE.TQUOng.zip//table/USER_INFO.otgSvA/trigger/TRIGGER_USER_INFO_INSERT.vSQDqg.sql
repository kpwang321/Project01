CREATE TRIGGER TRIGGER_USER_INFO_INSERT
  BEFORE INSERT
  ON USER_INFO
  FOR EACH ROW
  DECLARE
		integrity_error EXCEPTION ; errno INTEGER ; errmsg CHAR (200) ; dummy
		INTEGER ; found boolean ;
		BEGIN
		SELECT
		SEQ_USER_INFO.NEXTVAL INTO :new.ID
		from dual;
		EXCEPTION
		WHEN integrity_error THEN
		raise_application_error
		(errno, errmsg) ;
		END ;
/

