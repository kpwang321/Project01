CREATE TRIGGER TRIGGER_ORGANIZATION_INSERT
  BEFORE INSERT
  ON ORGANIZATION
  FOR EACH ROW
  DECLARE
		integrity_error EXCEPTION ; errno INTEGER ; errmsg CHAR (200) ; dummy
		INTEGER ; found boolean ;
		BEGIN
		SELECT
		SEQ_ORGANIZATION.NEXTVAL INTO
		:new.ID from dual;
		EXCEPTION
		WHEN integrity_error THEN
		raise_application_error (errno, errmsg) ;
		END ;
/

