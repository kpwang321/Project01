CREATE TRIGGER TRIGGER_SP_ME_INFO
  BEFORE INSERT
  ON SP_ME_INFO
  FOR EACH ROW
  declare
begin
select SEQ_SP_ME_INFO.nextval --自增序列
into :new.id from dual;
end;
/

