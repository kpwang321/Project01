CREATE TRIGGER TRIGGER_ORG_ROLE_INSERT
  BEFORE INSERT
  ON ORG_ROLE
  FOR EACH ROW
  DECLARE
		integrity_error EXCEPTION ; errno INTEGER ; errmsg CHAR (200) ; dummy
		INTEGER ; found
		boolean ;
		BEGIN
		SELECT
		seq_org_role.NEXTVAL INTO :new.ID
		from dual;
		EXCEPTION
		WHEN integrity_error THEN
		raise_application_error
		(errno, errmsg) ;
		END ;
/

