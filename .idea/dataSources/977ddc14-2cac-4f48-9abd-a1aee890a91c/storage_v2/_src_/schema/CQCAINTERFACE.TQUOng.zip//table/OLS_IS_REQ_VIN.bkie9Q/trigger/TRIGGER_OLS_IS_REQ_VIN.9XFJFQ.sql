CREATE TRIGGER TRIGGER_OLS_IS_REQ_VIN
  BEFORE INSERT
  ON OLS_IS_REQ_VIN
  FOR EACH ROW
  declare
begin
select SEQ_OLS_IS_REQ_VIN.nextval --自增序列
into :new.REQ_VIN_ID from dual;
end;
/

