CREATE procedure P_MES_IS_WENDDING_DATE(
STATE IN VARCHAR2,--传入需要查询的数据状态
ISOK OUT VARCHAR2,--返回是否执行成功
MESSAGE OUT varchar2--异常的返回JSON字符串
) is
errorException exception; --申明异常
isexistwd int:=0;--是否有焊装上线数据
isexitwending int:=0;--是否存在该车的焊装上线日期
isexitorder int:=0;--是否在生产通知单中存在
wendingvin varchar2(20);--VIN
wendingdate date;--每台车的焊装上线日期
oksum int:=0; --成功处理数据条数
cursor c1 is
    select *
      from T_MES_WEDDING_INFO t
     where t.r_status = '0';--查询未处理的接口数据进行处理

begin
  MESSAGE :=' ';
  --1、第一步，数据有效性验证，判断每台车的VIN是否重复等
  select count(1) into isexistwd from T_MES_WEDDING_INFO t where t.r_status = '0';
  if isexistwd >0 then
    FOR c_p IN c1 LOOP
    --判断该车是否存在焊装上线日期
         wendingvin := c_p.r_vin;
         wendingdate := c_p.r_wedding_date;
          select count(1) into isexitwending from T_FOLLOW_UP_MAIN t where t.type = 'EFER' and t.vin = wendingvin;
           if isexitwending >0 then
             if lengthb(MESSAGE) <600 then
              MESSAGE  := wendingvin||'已存在焊装上线数据，'||MESSAGE;
              end if;
           else
             --判断该车是否为订单车
             select count(1) into isexitorder from DCS_IS_PROD_NOTICE_CK_DTL_VIN t where t.vin = wendingvin;
             if isexitorder >0 then
                 --添加数据到DCS接口表中
                insert into  IS_DCS_WEDDING_INFO(wedding_info_id,R_VIN,INT_PROD_NOTICE_CK_DTL_VIN_ID,r_Wedding_Date,CODIFICATIO,M_READ_STATUS,R_CREATEDATE) values(SEQ_IS_DCS_WEDDING_INFO.Nextval,
                       wendingvin,(select tt.int_prod_notice_ck_dtl_vin_id from DCS_IS_PROD_NOTICE_CK t,DCS_IS_PROD_NOTICE_CK_DTL_VIN tt where t.int_prod_notice_id=tt.int_prod_notice_id and t.is_handle_status='51121002' and tt.vin=wendingvin ),
                       wendingdate,(select t.codificatio from T_ORDER_MAIN2 t where t.vin = wendingvin and rownum = 1),'20311001',sysdate);
                --添加数据到T_FOLLOW_UP_MAIN表中
                insert into T_FOLLOW_UP_MAIN(id,VIN,WEDDING_BUYOFF_FOBDATE,TYPE,UPLOADSTATE)  values(SEQ_T_FOLLOW_UP_MAIN.Nextval,wendingvin,wendingdate,'EFER','0');
                --更新接口表读取数据状态
                update T_MES_WEDDING_INFO t set t.r_status = '1' where t.r_vin = wendingvin;
                oksum :=oksum+1;
             else
               if lengthb(MESSAGE) <600 then
              MESSAGE  := wendingvin||'该车不在生产通知单中，'||MESSAGE;
              end if;
             end if;

       end if;
    end loop;
  commit;
       ISOK:='OK';
       MESSAGE :='成功获取焊装上线数据信息，共'|| oksum ||'条，'||MESSAGE;
  --2、第二步，传入每焊装上线车数据到IS业务表和DMS接口表，并修改接口表读取状态等信息


  --3、第三步，针对读取验证和写入数据的过程中记录的日志写入日志表


  --4、第四步，组装返回的状态和消息提示进行赋值返回

  else
    ISOK:='OK';
    MESSAGE:='没有需要读取的焊装上线接口数据';
    dbms_output.put_line('没有需要读取的焊装上线接口数据');
  end if;
  EXCEPTION
  WHEN others THEN
    dbms_output.put_line(sqlerrm);
    ISOK:='ERROR';
    MESSAGE:='读取数据失败:' || sqlerrm;
    rollback;
end P_MES_IS_WENDDING_DATE;
/

