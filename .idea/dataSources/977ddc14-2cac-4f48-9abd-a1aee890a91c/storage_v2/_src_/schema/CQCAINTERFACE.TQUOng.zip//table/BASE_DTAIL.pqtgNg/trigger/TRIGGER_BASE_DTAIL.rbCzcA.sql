CREATE TRIGGER TRIGGER_BASE_DTAIL
  BEFORE INSERT
  ON BASE_DTAIL
  FOR EACH ROW
  declare
begin
select SEQ_BASE_DTAIL.nextval --自增序列
into :new.id from dual;
end;
/

