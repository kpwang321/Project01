CREATE TRIGGER TRIGGER_PERMISSION_INSERT
  BEFORE INSERT
  ON PERMISSION
  FOR EACH ROW
  DECLARE
		integrity_error EXCEPTION ; errno INTEGER ; errmsg CHAR (200) ; dummy
		INTEGER ; found boolean ;
		BEGIN
		SELECT
		SEQ_PERMISSION.NEXTVAL INTO
		:new.ID from dual;
		EXCEPTION
		WHEN integrity_error THEN
		raise_application_error (errno, errmsg) ;
		END ;
/

