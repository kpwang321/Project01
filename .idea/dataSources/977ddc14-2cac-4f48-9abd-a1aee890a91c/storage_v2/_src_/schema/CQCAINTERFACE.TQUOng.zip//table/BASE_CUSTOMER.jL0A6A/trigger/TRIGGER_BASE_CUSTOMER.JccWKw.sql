CREATE TRIGGER TRIGGER_BASE_CUSTOMER
  BEFORE INSERT
  ON BASE_CUSTOMER
  FOR EACH ROW
  declare
begin
select SEQ_BASE_CUSTOMER.nextval --自增序列
into :new.id from dual;
end;
/

