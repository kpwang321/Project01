CREATE TRIGGER TRIGGER_SFTP_LOG
  BEFORE INSERT
  ON SFTP_LOG
  FOR EACH ROW
  declare
begin
select SEQ_SFTP_LOG.nextval --自增序列
into :new.id from dual;
end;
/

