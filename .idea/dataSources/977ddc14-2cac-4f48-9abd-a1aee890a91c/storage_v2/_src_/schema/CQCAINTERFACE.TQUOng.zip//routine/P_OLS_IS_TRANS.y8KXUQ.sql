CREATE procedure P_OLS_IS_TRANS(
STATE IN VARCHAR2,--传入需要查询的数据状态
ISOK OUT VARCHAR2,--返回是否执行成功
MESSAGE OUT varchar2--异常的返回JSON字符串
) is
rowRecord number(10);--已发运接口表待读取数据数量
isexitfayun int:=0;--是否已经传过发运数据
isexistplan int:=0;--是否存在发运指令
outvin varchar2(20);--存取VIN
OutWarehouseDate date;--出库日期
tcdate date;--原提车日期
oksum int:=0; --成功处理数据条数
contract_no varchar2(30);
model_code varchar2(30);
package_code varchar2(30);
haveorder int:=0;
cursor c1 is

    select * from OLS_IS_REQ_VIN t where t.out_warehouse_date is not null and t.arrive_seaport_date is null and t.del_flag ='0'
    and t.is_handle_status = '51101001';--查询未处理的接口数据进行处理   
          
begin
       select count(1) into rowRecord from OLS_IS_REQ_VIN t where t.out_warehouse_date is not null and t.arrive_seaport_date is null and t.del_flag ='0'
       and t.is_handle_status = '51101001';
       
       MESSAGE := ' ';
       
       IF rowRecord>0 THEN--判断是否有需要读取的发运出库数据
         FOR c_p IN c1 LOOP
         --判断该车是否存在发运出库数据 
         --判断该车是否存在发运指令数据
         outvin := c_p.vin;
         OutWarehouseDate := c_p.out_warehouse_date;--离开园区时间
         
          select count(1) into isexitfayun from T_DISTRIBUTION_TRACKER t where t.vin = outvin;
           
          select count(1) into isexistplan from T_DISTRIBUTION_PLAN t where t.vin = outvin; 
           if isexitfayun >0 then
             if lengthb(MESSAGE) <600 then
              MESSAGE  := outvin||'已存在发运数据，'+MESSAGE;
              end if;
           else if isexistplan <=0 then   
             if lengthb(MESSAGE) <600 then
              MESSAGE  := outvin||'没有发运指令数据，'+MESSAGE;
              end if;
           else
              --在已发运数据表中添加数据
              insert into T_DISTRIBUTION_TRACKER(id,VIN,STATE,DATMVT_G,NUMOF_G,PSVDE_G)  values(SEQ_T_DISTRIBUTION_TRACKER.Nextval,outvin,'0',to_char(OutWarehouseDate,'yyyyMMdd'),(select t.noaff_s from T_DISTRIBUTION_PLAN t where t.vin = outvin and rownum = 1),(select t.demand_s from T_DISTRIBUTION_PLAN t where t.vin = outvin and rownum = 1));
              --向订单跟踪表中插入离园时间(国际公司提车时间)
              select count(1) into haveorder from DCS_IS_PROD_NOTICE_CK_DTL_VIN tt,Dcs_Is_Prod_Notice_Ck t,IS_DCS_ORDER_TRACE tn 
              where t.int_prod_notice_id=tt.int_prod_notice_id 
              and tn.contractnum = tt.contract_no and tn.clxh = tt.model_code and tn.cxzt = tt.package_code
              and t.is_handle_status='51121002'
              and tt.vin = outvin;
              if haveorder >0 then --判断该车是否在订单跟踪表中
              tcdate := null;
              contract_no := '';
              model_code := '';
              package_code := '';
              select tn.tcdate,tt.contract_no,tt.model_code,tt.package_code into tcdate,contract_no,model_code,
              package_code from DCS_IS_PROD_NOTICE_CK_DTL_VIN tt,Dcs_Is_Prod_Notice_Ck t,IS_DCS_ORDER_TRACE tn 
              where t.int_prod_notice_id=tt.int_prod_notice_id 
              and tn.contractnum = tt.contract_no and tn.clxh = tt.model_code and tn.cxzt = tt.package_code
              and t.is_handle_status='51121002'
              and tt.vin = outvin; --判断该车是否为订单车
              
              if tcdate is not null then
                if tcdate < OutWarehouseDate then
                  update IS_DCS_ORDER_TRACE t set t.tcdate = OutWarehouseDate where t.contractnum = contract_no and t.clxh = model_code and t.cxzt = package_code;
                end if;
              else
                  update IS_DCS_ORDER_TRACE t set t.tcdate = OutWarehouseDate where t.contractnum = contract_no and t.clxh = model_code and t.cxzt = package_code;
              end if;
               else

                ISOK:='OK';
                if lengthb(MESSAGE) <600 then
                MESSAGE  := outvin||'不在生产通知单中，'||MESSAGE;
                end if;
              end if;
              
              --添加成功后，ols接口表中修改读取状态
              update OLS_IS_REQ_VIN t set t.is_handle_status = '51101002',t.is_handle_date = sysdate where t.vin = outvin and t.out_warehouse_date is not null and t.arrive_seaport_date is null and t.del_flag ='0' and t.is_handle_status = '51101001'; 

              oksum :=oksum+1; 
           end if;  
           end if;
         end loop;
       commit;  
       ISOK:='OK';
       MESSAGE :='成功获取已发运信息，共'|| oksum ||'条，'||MESSAGE;
  else
    ISOK:='OK';
    MESSAGE:='没有需要读取的已发运接口数据';
    dbms_output.put_line('没有需要读取的已发运接口数据');
  end if;
  EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line('读取数据失败');
    ISOK:='ERROR';
    MESSAGE:='读取数据失败:' || sqlerrm;
    rollback;
end P_OLS_IS_TRANS;
/

