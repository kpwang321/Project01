CREATE TRIGGER TRIGGER_SP_PUR_ORDERINFO
  BEFORE INSERT
  ON SP_PUR_ORDERINFO
  FOR EACH ROW
  declare
begin
select SEQ_SP_PUR_ORDERINFO.nextval --自增序列
into :new.id from dual;
end;
/

