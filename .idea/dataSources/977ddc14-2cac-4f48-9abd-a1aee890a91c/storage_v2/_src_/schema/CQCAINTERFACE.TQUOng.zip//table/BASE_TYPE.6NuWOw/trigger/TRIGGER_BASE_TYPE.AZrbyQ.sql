CREATE TRIGGER TRIGGER_BASE_TYPE
  BEFORE INSERT
  ON BASE_TYPE
  FOR EACH ROW
  declare
begin
select SEQ_BASE_TYPE.nextval --自增序列
into :new.id from dual;
end;
/

