CREATE procedure P_MES_IS_BUYOFF_DATE(
  STATE IN VARCHAR2,--传入需要查询的数据状态
  ISOK OUT VARCHAR2,--返回是否执行成功
  MESSAGE OUT varchar2--异常的返回JSON字符串
) is
  errorException exception; --申明异常
  isexistbuyoff int:=0;--是否有BUY-OFF数据
  isexitbuyoff int:=0;--是否存在该车的BUY-OFF日期
  isexitorder int:=0;--是否在生产通知单中存在
  isexitengineer int:=0;--是否在发动机追溯件
  buyoffvin varchar2(20);--VIN
  buyoffdate date;--每台车的BUY-OFF日期
  oksum int:=0; --成功处理数据条数
  
  rkdate date;--原BUYOFF日期
  contract_no varchar2(30);--合同号+版本
  model_code varchar2(30);--车型
  package_code varchar2(30);--车型状态
  haveorder int:=0;--是否该车在生产通知单中存在
  
  cursor c1 is
      select *
        from T_MES_BUYOFF_INFO t
       where t.r_status = '0';--查询未处理的接口数据进行处理    
begin
  
  MESSAGE  :=' ';
  --1、第一步，做数据验证
  select count(1) into isexistbuyoff from T_MES_BUYOFF_INFO t where t.r_status = '0'; 
  if isexistbuyoff>0 then--判断是否有需要读取的接口数据
  
  FOR c_p IN c1 LOOP
    --判断是否已经有该车的BUYOFF数据
      buyoffvin := c_p.r_vin;
      buyoffdate := c_p.r_buyoff_date;
      select count(1) into isexitbuyoff from T_FOLLOW_UP_MAIN t where t.type = 'SMON' and t.vin = buyoffvin;
           if isexitbuyoff >0 then
             if lengthb(MESSAGE) <600 then
               MESSAGE  := buyoffvin||'已存在BUY-OFF数据，'||MESSAGE;
             end if; 
           else 
             --判断该车是否为订单车
             select count(1) into isexitorder from DCS_IS_PROD_NOTICE_CK_DTL_VIN t where t.vin = buyoffvin;
             if isexitorder >0 then
               --由于需要添加发动机号和追溯件信息进入接口表，所以需要判断下发动机号是否存在
               select count(1) into isexitengineer from T_MES_TRACEABILITY_INFO t where t.r_vin = buyoffvin and t.r_partname = 'Engine'; 
                if isexitengineer>0 then
                --添加BUYOFF数据到DCS接口表中
                insert into  IS_DCS_BUYOFF_INFO(buyoff_info_id,R_VIN,INT_PROD_NOTICE_CK_DTL_VIN_ID,r_buyoff_Date,CODIFICATIO,M_READ_STATUS,R_CREATEDATE,FDJH) values(SEQ_IS_DCS_BUYOFF_INFO.Nextval,
                       buyoffvin,(select tt.int_prod_notice_ck_dtl_vin_id from DCS_IS_PROD_NOTICE_CK t,DCS_IS_PROD_NOTICE_CK_DTL_VIN tt where t.int_prod_notice_id=tt.int_prod_notice_id and t.is_handle_status='51121002' and tt.vin=buyoffvin ),
                       buyoffdate,(select t.codificatio from T_ORDER_MAIN2 t where t.vin = buyoffvin and rownum = 1),'20311001',sysdate,
                       (select distinct(t.partnumber) from T_TRACE_DETAIL t  where t.vin = buyoffvin and t.partname = 'Engine'));
                --添加数据到T_FOLLOW_UP_MAIN表中
                insert into T_FOLLOW_UP_MAIN(id,VIN,WEDDING_BUYOFF_FOBDATE,TYPE,UPLOADSTATE)  values(SEQ_T_FOLLOW_UP_MAIN.Nextval,buyoffvin,buyoffdate,'SMON','0');
                --把生产序列APVR值更新到FOB表中
                --1、生成SPVR
                update T_FOB_SCMX t set t.apvpr = (select (to_date(to_char(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd')-to_date('1976-11-8','yyyy-MM-dd'))|| 'YV1'|| replace(rpad(' ',4- length(c_p.r_apvpr)),' ','0') || c_p.r_apvpr  from dual) where t.vin = buyoffvin;
                
                --将追踪件信息读取到IS系统
                --获取追溯件的类别编码
               
                FOR c_l IN (select SEQ_T_TRACE_DETAIL.NEXTVAL as id,t.r_vin,t.r_serial_number,t.r_partname,1,'',t.r_type,t.r_supplier_code,t.r_manufacturing_date,t.r_hardware_part_number,t.r_hardware_number,t.r_software_part_number,t.r_software_number from T_MES_TRACEABILITY_INFO t where t.r_status = '0' and t.r_vin = buyoffvin) LOOP
                  if c_l.r_partname = 'Engine' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'10',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);
                  end if;
                  if c_l.r_partname = 'Gearbox' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'20',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'Transfer box' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'90',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'Body in withe' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'50',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'Steering wheel airbag' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'5A',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'Front seat airbag' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'5B',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'Dashboard airbag' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'5E',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'Airbag – right curtain' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'5X',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'Airbag – left curtain' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'5Z',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'AVM' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'2E',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'EMS' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4A',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'iBCM' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4B',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'TCU' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4D',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'AC' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4J',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'IP' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4K',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'SRS' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4M',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'ESP / ABS' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4P',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'RRS' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4R',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'ESCL' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4V',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'HU' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'4X',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'EPS' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'6L',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'LDW' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'6Y',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'SAS' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'8F',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'EPBi' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'8K',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'ACC' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'L6',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'EDL' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'L7',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'IMMO' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'L8',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'AWD' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'C9',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                  if c_l.r_partname = 'GW' then
                     insert into T_TRACE_DETAIL values(c_l.id,c_l.r_vin,c_l.r_serial_number,'E7',c_l.r_partname,1,'',c_l.r_type,c_l.r_supplier_code,c_l.r_manufacturing_date,c_l.r_hardware_part_number,c_l.r_hardware_number,c_l.r_software_part_number,c_l.r_software_number);                    
                  end if;
                end loop;
                 
                --添加BUYOFF时间到订单跟踪表
                select count(1) into haveorder from DCS_IS_PROD_NOTICE_CK_DTL_VIN tt,Dcs_Is_Prod_Notice_Ck t,IS_DCS_ORDER_TRACE tn 
                where t.int_prod_notice_id=tt.int_prod_notice_id 
                and tn.contractnum = tt.contract_no and tn.clxh = tt.model_code and tn.cxzt = tt.package_code
                and t.is_handle_status='51121002'
                and tt.vin = buyoffvin; 
              if haveorder >0 then--判断该车是否在生产通知单中
                rkdate := null;
                contract_no := '';
                model_code := '';
                package_code := '';
                select tn.rkdate,tt.contract_no,tt.model_code,tt.package_code into rkdate,contract_no,model_code,
                package_code from DCS_IS_PROD_NOTICE_CK_DTL_VIN tt,Dcs_Is_Prod_Notice_Ck t,IS_DCS_ORDER_TRACE tn 
                where t.int_prod_notice_id=tt.int_prod_notice_id 
                and tn.contractnum = tt.contract_no and tn.clxh = tt.model_code and tn.cxzt = tt.package_code
                and t.is_handle_status='51121002'
                and tt.vin = buyoffvin; --判断该车是否为订单车
              
              if rkdate is not null then--判断入库时间是否为空
                if rkdate < buyoffdate then
                  update IS_DCS_ORDER_TRACE t set t.rkdate = buyoffdate where t.contractnum = contract_no and t.clxh = model_code and t.cxzt = package_code;
                end if;
              else
                  update IS_DCS_ORDER_TRACE t set t.rkdate = buyoffdate where t.contractnum = contract_no and t.clxh = model_code and t.cxzt = package_code;
              end if;
                
              else
                ISOK:='OK';
                if lengthb(MESSAGE) <600 then
                  MESSAGE  := buyoffvin||'不在生产跟踪表中，'||MESSAGE;
                end if;
              end if;
                --更新追溯件接口表数据的读取状态
                update T_MES_TRACEABILITY_INFO t set t.r_status='1'  where t.r_status = '0' and t.r_vin = buyoffvin;
                --更新接口表读取数据状态
                update T_MES_BUYOFF_INFO t set t.r_status = '1' where t.r_vin = buyoffvin;
                oksum :=oksum+1; 
                else
                if lengthb(MESSAGE) <600 then
                   --dbms_output.put_line(MESSAGE);
                   MESSAGE  := (buyoffvin||'该车追溯件中没有发动机信息，'||MESSAGE);
                end if;   
                end if;
             else
                if lengthb(MESSAGE) <600 then
                  MESSAGE  := (buyoffvin||'该车不在生产通知单中，'||MESSAGE);
                end if;
               end if;
           end if;
  end loop;
      commit;  
      ISOK:='OK';
      MESSAGE :='成功获取BUY-OFF信息，共'|| oksum ||'条，'||MESSAGE;
  --如果MESSAGE的长度超过4000，需要截取
/*    if lengthb(MESSAGE) >4000 then
      MESSAGE  := substr(MESSAGE,4000);
    end if;*/
  else
    ISOK:='OK';
    MESSAGE:='没有需要读取的BUY-OFF接口数据';
    dbms_output.put_line('没有需要读取的BUY-OFF接口数据');
  end if;
  EXCEPTION
  WHEN others THEN
    dbms_output.put_line('读取数据失败');
    ISOK:='ERROR';
    MESSAGE:='读取数据失败:' || sqlerrm;
    rollback;
end P_MES_IS_BUYOFF_DATE;
/

