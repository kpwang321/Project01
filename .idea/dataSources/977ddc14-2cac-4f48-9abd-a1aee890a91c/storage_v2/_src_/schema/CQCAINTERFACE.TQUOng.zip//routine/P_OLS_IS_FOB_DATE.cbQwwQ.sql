CREATE procedure P_OLS_IS_FOB_DATE(
STATE IN VARCHAR2,--传入需要查询的数据状态
ISOK OUT VARCHAR2,--返回是否执行成功
MESSAGE OUT varchar2--异常的返回JSON字符串
) is
errorException exception; --申明异常
rowRecord number(10);--FOB接口表待读取数据数量
isexitfob number(10);--是否已经传过FOB
fobvin varchar2(20);--存取VIN
fobdate date;--FOB的日期
fydate date;--原发运日期
oksum int:=0; --成功处理数据条数
contract_no varchar2(30);
model_code varchar2(30);
package_code varchar2(30);
haveorder int:=0;
cursor c1 is

    select * from OLS_IS_REQ_VIN t where t.arrive_seaport_date is not null 
    and t.is_handle_status = '51101001';--查询未处理的接口数据进行处理   
          
begin
       select count(1) into rowRecord from OLS_IS_REQ_VIN t where t.arrive_seaport_date is not null 
       and t.is_handle_status = '51101001';
       MESSAGE:=' ';
       IF rowRecord>0 THEN--判断是否有需要读取的FOB数据
         FOR c_p IN c1 LOOP
         --判断该车是否存在FOB 
         fobvin := c_p.vin;
         fobdate := c_p.arrive_seaport_date;
          select count(1) into isexitfob from T_FOLLOW_UP_MAIN t where t.type = 'ECOM' and t.vin = fobvin;
           if isexitfob >0 then
             if lengthb(MESSAGE) <600 then
              MESSAGE  := fobvin||'已存在FOB数据，'||MESSAGE;
              end if;
           else
              --在生产跟踪表中添加FOB时间
              insert into T_FOLLOW_UP_MAIN(id,VIN,WEDDING_BUYOFF_FOBDATE,TYPE,UPLOADSTATE)  values(SEQ_T_FOLLOW_UP_MAIN.Nextval,fobvin,fobdate,'ECOM','0');
              --向订单跟踪表中插入发运时间
              select count(1) into haveorder from DCS_IS_PROD_NOTICE_CK_DTL_VIN tt,Dcs_Is_Prod_Notice_Ck t,IS_DCS_ORDER_TRACE tn 
              where t.int_prod_notice_id=tt.int_prod_notice_id 
              and tn.contractnum = tt.contract_no and tn.clxh = tt.model_code and tn.cxzt = tt.package_code
              and t.is_handle_status='51121002'
              and tt.vin = fobvin; 
              if haveorder >0 then--判断该车是否在生产通知单中
              fydate := null;
              contract_no := '';
              model_code := '';
              package_code := '';
              select tn.fydate,tt.contract_no,tt.model_code,tt.package_code into fydate,contract_no,model_code,
              package_code from DCS_IS_PROD_NOTICE_CK_DTL_VIN tt,Dcs_Is_Prod_Notice_Ck t,IS_DCS_ORDER_TRACE tn 
              where t.int_prod_notice_id=tt.int_prod_notice_id 
              and tn.contractnum = tt.contract_no and tn.clxh = tt.model_code and tn.cxzt = tt.package_code
              and t.is_handle_status='51121002'
              and tt.vin = fobvin; --判断该车是否为订单车
              
              if fydate is not null then
                if fydate < fobdate then
                  update IS_DCS_ORDER_TRACE t set t.fydate = fobdate where t.contractnum = contract_no and t.clxh = model_code and t.cxzt = package_code;
                end if;
              else
                  update IS_DCS_ORDER_TRACE t set t.fydate = fobdate where t.contractnum = contract_no and t.clxh = model_code and t.cxzt = package_code;
              end if;
                
              else
                ISOK:='OK';
                if lengthb(MESSAGE) <600 then
                MESSAGE  := fobvin||'不在生产通知单中，'||MESSAGE;
                end if;
              end if;
              --添加成功后，ols接口表中修改读取状态
              update OLS_IS_REQ_VIN t set t.is_handle_status = '51101002',t.is_handle_date = sysdate where t.vin = fobvin and t.arrive_seaport_date is not null and t.is_handle_status = '51101001'; 
              oksum :=oksum+1; 
           end if;  
         
         end loop;
       commit;  
       ISOK:='OK';
       MESSAGE :='成功获取FOB信息，共'|| oksum ||'条，'||MESSAGE;
  else
    ISOK:='OK';
    MESSAGE:='没有需要读取的FOB接口数据';
    dbms_output.put_line('没有需要读取的FOB接口数据');
  end if;
  EXCEPTION
  WHEN others THEN
    dbms_output.put_line('读取数据失败');
    ISOK:='ERROR';
    MESSAGE:='读取数据失败:' || sqlerrm;
    rollback;
end P_OLS_IS_FOB_DATE;
/

