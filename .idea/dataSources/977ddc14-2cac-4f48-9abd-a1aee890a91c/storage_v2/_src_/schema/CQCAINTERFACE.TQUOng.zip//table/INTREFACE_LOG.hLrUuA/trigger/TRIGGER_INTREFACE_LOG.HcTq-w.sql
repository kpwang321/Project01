CREATE TRIGGER TRIGGER_INTREFACE_LOG
  BEFORE INSERT
  ON INTREFACE_LOG
  FOR EACH ROW
  declare
begin
select SEQ_INTREFACE_LOG.nextval --自增序列
into :new.id from dual;
end;
/

